public class empat {
  public static void main(String[] args){
    String s = new String("Hallo saya achmaD nur");
    System.out.println("Sebelum dilakukan replace : "+ s);
    System.out.println("Setelah dilakukan replace(\'D\', \'m\') : "+ s. replace('D', 'm'));
  }
}