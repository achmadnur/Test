<?php
$server = "localhost";
$user = "root";
$password ="";
$db ="tronjol";

$konek=mysql_connect($server,$user,$password)
	or die("hubungi administrator".mysql_error());
$bukadb=mysql_select_db($db)
	or die("koneksi database gagal".mysql_error());
	?>