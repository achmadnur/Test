<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
 
 
<table border="1" cellpadding="5" cellspacing="0">
     
<tr>
         
<th> Id </th>
 
         
<th> Nama </th>
 
         
<th> Nama Hobi </th>
    </tr>
 
     
 
    <?php
        include 'konek.php';
 
        $select = "select categories.id, categories.name, hobbies.nama from categories inner join hobbies on categories.id = hobbies.person_id ;";
        $query = mysql_query($select);
 
        $no=0;
        while ($data = mysql_fetch_array($query)) {
            $id         = $data['id'];  
            $name       = $data['name'];
            $nama  		= $data['nama'];
 
            echo "
                 
<tr>
                     
<td> $id </td>
 
                     
<td> $name </td>
 
                     
<td> $nama </td>
 
                     
<td>
                        <a href='#'> Edit </a> 
                        <a href='#'> Delete </a>   
                    </td>
 
                </tr>
 
            ";
        }
 
    ?>
</table>
 
 
</body>
</html>